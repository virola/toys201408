/**
 * @file 工具栏模块
 * @author  virola<virola.zhu@gmail.com>
 */

define(function (require) {

    // TODO
    var exports = {};

    return exports;
});

